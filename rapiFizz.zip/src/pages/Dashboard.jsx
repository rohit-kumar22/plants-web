import { API } from "../config/api";
import useFetch from "../hooks/useFetch";
import { useDispatch } from "react-redux";
import { addToCart } from "../redux/cartSlice";

export default function Dashboard() {
  const { data: products, loading } = useFetch(API.PRODUCTS_LIST);
  const dispatch = useDispatch();

  const groupByCategory = (items) => {
    return items?.reduce((acc, item) => {
      if (!acc[item.category]) acc[item.category] = [];
      acc[item.category].push(item);
      return acc;
    }, {});
  };

  const allProducts = groupByCategory(products || []);

  return (
    <div>
      {loading ? (
        <div className="h-[calc(100vh-295px)]">
          <p className="p-5 text-center text-black">Loading.....</p>
        </div>
      ) : (
        <div className="px-5">
          {Object.keys(allProducts).map((category) => (
            <div key={category} className="py-5">
              <h2 className="text-xl font-bold mb-3 text-black">
                {category.toUpperCase()}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 justify-center">
                {allProducts[category].map((product) => (
                  <div
                    key={product.id}
                    className="border p-4 shadow-lg rounded-lg"
                  >
                    <img
                      src={product.image}
                      alt={product.title}
                      className="h-40 w-full object-contain mb-2"
                    />
                    <h3 className="text-lg font-semibold text-gray-500">
                      {product.description.slice(0, 20)}
                    </h3>
                    <p className="text-green-600 font-bold mt-2">
                      ${product.price}
                    </p>
                    <p className="text-yellow-500">
                      ⭐ {product.rating.rate} | {product.rating.count}
                    </p>
                    <div className="flex justify-end">
                      <button
                        className="bg-yellow-500 text-sm text-white px-3 py-1 rounded mt-3"
                        onClick={() => dispatch(addToCart(product))}
                      >
                        Add to Cart
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
