import {
  SlSocialFacebook,
  SlSocialInstagram,
  SlSocialTwitter,
  SlSocialLinkedin,
} from "react-icons/sl";

export default function Footer() {
  return (
    <div>
      <footer className="bg-pink-700 text-white pb-10 md:pt-5 relative px-5">
        {/* ---------- social icons ------------ */}
        <div className="py-5">
          <div className=" mx-auto">
            <div className="text-lg text-center space-x-2 flex gap-3 justify-center">
              <i className="hover:text-yellow-500 duration-300 cursor-pointer">
                <SlSocialFacebook />
              </i>
              <i className="hover:text-yellow-500 duration-300 cursor-pointer">
                <SlSocialInstagram />
              </i>
              <i className="hover:text-yellow-500 duration-300 cursor-pointer">
                <SlSocialLinkedin />
              </i>
              <i className="hover:text-yellow-500 duration-300 cursor-pointer">
                <SlSocialTwitter />
              </i>
            </div>
          </div>
        </div>

        {/* ---------- copyright ------------ */}

        <div className="">
          <p className="text-center mt-10 opacity-50">
            Copyright &copy; 2025 rapifuzz. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
