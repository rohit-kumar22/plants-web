import { FiShoppingCart } from "react-icons/fi";
import { useSelector } from "react-redux";
import { useNavigate, useLocation, Link } from "react-router-dom";

export default function Header() {
  const totalQuantity = useSelector((state) => state.cart.totalQuantity);
  const navigate = useNavigate();
  const location = useLocation().pathname;

  const handleNavigate = () => {
    navigate("/cart");
  };

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    navigate("./login");
  };

  return (
    <div>
      <header
        id="navbar"
        className="bg-pink-700 fixed w-full top-0 left-0 z-50 mb-5"
      >
        <nav className="px-5 flex items-center justify-between h-16 sm:h-20">
          <div className=" sm:text-2xl text-white">RapiFuzz</div>
          <div className="flex gap-10">
            {location === "/dashboard" ? (
              <div
                className="text-2xl pr-5 flex cursor-pointer pt-5"
                onClick={handleNavigate}
              >
                <i className="hover:text-yellow-500">
                  <FiShoppingCart />
                </i>
                <p className="mb-5 text-sm align-super pl-1">{totalQuantity}</p>
              </div>
            ) : (
              <Link
                to="/dashboard"
                className="font-semibold hover:text-yellow-500 pt-5"
              >
                Home
              </Link>
            )}
            <div className="p-2 w-24 mt-2 h-12 rounded border-2 border-white cursor-pointer hover:font-semibold">
              <button className="text-white flex pl-2" onClick={handleLogout}>
                Logout
              </button>
            </div>
          </div>
        </nav>
      </header>
    </div>
  );
}
